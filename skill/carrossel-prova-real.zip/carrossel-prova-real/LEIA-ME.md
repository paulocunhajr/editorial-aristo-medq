# carrossel-prova-real

Skill para o Claude produzir carrosséis "prova real" (Aristo + MedQ) a partir do Radar de Conteúdo Editorial (PDF) e do banco de questões (CSV).

## Como instalar
- **Claude.ai / app:** Configurações → Capacidades → Skills → Enviar skill → escolha este .zip.
- **Claude Code:** descompacte em `~/.claude/skills/` (fica `~/.claude/skills/carrossel-prova-real/SKILL.md`).

## Como usar
Peça algo como: "Monte os carrosséis da semana de 07/12 a 13/12 com o radar da SES-DF 2024 e o banco de questões" e anexe os arquivos. O Claude segue o SKILL.md:
1. extrai o relatório;
2. escolhe as questões;
3. escreve os ganchos;
4. confere números e textos;
5. renderiza os JPGs, os ZIPs e a biblioteca HTML.

## Requisitos para renderizar
Python 3.10+, `pip install playwright pillow`, `python -m playwright install chromium` e `pdftotext` (poppler-utils).

## Conteúdo
- `SKILL.md`: o fluxo.
- `references/`: regras editoriais, formato do conteúdo e exemplo real da semana USP-SP/IPSEMG.
- `scripts/`: extração do radar, busca no banco, conferência de números e renderização.
- `assets/`: logos, fonte Public Sans (OFL) e modelo da biblioteca HTML.
