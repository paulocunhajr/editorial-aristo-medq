---
name: carrossel-prova-real
description: Produz carrosséis de Instagram "prova real" para as marcas Aristo e MedQ (residência médica) a partir do relatório "Radar de Conteúdo Editorial" do painel Aristo (PDF) e do banco de questões (CSV). Gera ganchos com o % real de erro, a questão oficial na íntegra, o card de dados, a resolução e o fechamento em JPG 1080x1350, além de legendas, ZIPs e uma biblioteca HTML offline. Use sempre que alguém pedir carrossel, post, gancho, hook ou semana de conteúdo sobre uma prova de residência (USP-SP, IPSEMG, SES-DF, ENARE, PSU-MG, etc.), mandar um radar editorial ou relatório de desempenho de prova, ou falar em "prova real", PMB, ponto cego ou pulo do gato, mesmo sem citar a skill.
---

# Carrossel "prova real" (Aristo + MedQ)

Transforma o desempenho real dos alunos numa prova em carrosséis com gancho forte e dado verdadeiro. O valor do formato está em duas coisas que não podem quebrar: **cada número vem do relatório** e **cada questão é a oficial, palavra por palavra**. O resto (gancho, ritmo, visual) serve a essas duas.

## O que você precisa receber

1. **Radar de Conteúdo Editorial** (PDF do painel Aristo) de cada prova. Traz o acerto geral, o acerto por quintil e o distrator dominante, organizados por linha editorial (PMB, Ponto Cego de nível, Ponto Cego de raciocínio, Pulo do Gato, Conteúdos fundamentais).
2. **Banco de questões** `questoes-discriminacao*.csv`. A versão completa tem alternativas, gabarito e comentário; a simples, só o enunciado.
3. **Datas e grade:** quais dias, quais provas, quantos posts por marca. Na dúvida, um por dia por marca, alternando as provas.
4. **Imagens originais** das questões que dependem de figura. Sem a imagem, a questão fica de fora.

Se algo faltar, pergunte antes de produzir. Nunca preencha um número com estimativa.

## Fluxo

### 1. Extrair os relatórios
```bash
python3 scripts/extrair_radar.py radar_prova.pdf > radar_prova.json
```
Confira o cabeçalho de cada um:
- **Amostra pequena** (o relatório avisa, ou poucas dezenas de alunos): descarte o relatório.
- **Incoerência** (por exemplo, o quintil do topo com 0% num item que 80% acertaram, ou o número de itens maior que o de uma prova): não use e avise.

### 2. Escolher as questões
Comece pelos itens de exemplo do relatório, que já vêm com o texto completo e o % do distrator. Complete com os itens das tabelas, buscando o texto no banco:
```bash
python3 scripts/buscar_questao.py banco.csv USP-SP 2024 Q082 Q004
```
Descarte, e registre o motivo:
- **Imagem ausente:** a questão depende de figura ("conforme imagem") e a figura não foi recebida.
- **Discriminação negativa ou indeterminada** no banco.
- **Gabarito discutível:** mais de uma alternativa defensável, ou gabarito que contraria diretriz atual. Confira cada gabarito com a literatura antes de escrever.

Prefira variar áreas e misturar as linhas editoriais. Os ganchos mais fortes saem de Ponto Cego de raciocínio (o distrator atraiu mais que o gabarito) e de acerto geral baixo.

### 3. Escrever o conteúdo
Copie `references/exemplo_conteudo_semana_usp_ipsemg.py` e preencha um dicionário por post. O formato está em `references/formato_conteudo.md`. **Leia `references/regras_editoriais.md` antes de escrever**: ali estão a anatomia do gancho, o que cada marca enfatiza, as frases proibidas e a revisão de texto.

O resumo:
- **Gancho** = a cena clínica concreta + o % real de erro. Exemplo: "Úlcera venosa aberta nas duas pernas. **44% chamaram de cicatrizada.**"
- **% de erro** = 100 − acerto geral (56,9% de acerto → 43% erraram). Isso é derivado do relatório, não estimativa.
- **Fora da capa e da legenda:** "medianos", "quintil" e o número de alunos que fizeram a prova (amostra pequena enfraquece o argumento). Os quintis vão só no card de dados, com nome claro: "alunos com nota média (3º quintil)".
- **Enunciado e alternativas literais.** Pode corrigir digitação evidente (acento, espaço). Enunciado longo vira uma lista de partes: o renderizador faz um card por parte, sem cortar texto.

### 4. Conferir
```bash
python3 scripts/conferir.py conteudo.py --banco banco.csv --radar radar_a.json radar_b.json
```
Ele aponta como erro:
- gabarito diferente do banco;
- qualquer % ou "pontos" sem origem no relatório (nem no número, nem no complemento, nem na diferença entre quintis);
- frase proibida na capa, no fechamento ou na legenda.

Também mostra REVISAR quando o texto difere do banco. Corrija até sair sem erro.

### 5. Renderizar
```bash
pip install playwright pillow && python3 -m playwright install chromium   # só na primeira vez
python3 scripts/render.py --conteudo conteudo.py --saida entrega/
```
Para usar um Chromium já instalado, defina `CHROME=/caminho/do/chrome`. A saída tem:
- `p/<Marca>/<AAAA-MM-DD>/post-01/` com `01.jpg…` e `legenda.txt`;
- `z/` com um ZIP por post e um por dia;
- `index.html`, a biblioteca offline com calendário, filtros, prévias, legenda e ficha.

Se o script avisar "transborda", encurte o texto ou divida o enunciado em mais partes.

### 6. Revisar visualmente e entregar
Monte uma folha de contato e olhe todos os cards. Os pontos mais comuns são texto colado no logo, card com muito vazio e quebra estranha em número ("dia\n16"). Use ` ` (espaço que não quebra) entre o número e a palavra.

Na entrega, mostre:
- a grade (dia, marca, prova, gancho);
- o que foi descartado e por quê;
- as pendências.

Todo post nasce **PENDENTE de revisão docente e conferência visual**. Não marque como pronto nem publique sem aprovação humana.

## Armadilhas que já aconteceram
- **Percentual "sem fonte":** outra IA removeu os % de erro dizendo que não tinham fonte. Têm: são o complemento do acerto geral. Registre a conta na ficha (`justificativa_selecao`) para não haver dúvida.
- **Relatório repetido:** dois relatórios da mesma instituição podem trazer as mesmas questões com números diferentes (provas misturadas). Use o que tiver amostra coerente.
- **Comentário oficial com erro:** já houve comentário dizendo "Alternativa A – Correta" e fechando com gabarito D. Confie no gabarito conferido com a literatura e avise quem cuida da plataforma.
- **Gabarito contestável:** um gabarito oficial pode ser uma afirmação lateral (por exemplo, uma descrição radiológica num caso que exige antibiótico). Na dúvida, descarte.
