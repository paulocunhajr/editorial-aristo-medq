# Formato do arquivo de conteúdo (`conteudo.py`)

O arquivo é Python puro e define:

```python
PROVAS = {'USP-SP': '06/12/2026', 'IPSEMG': '06/12/2026'}      # banca -> data da prova (aparece na ficha)
FONTES = {'USP-SP': 'radar-editorial-USP-SP-SP-2024.pdf'}      # opcional: origem dos números (ficha)
VERSAO = 'v1'                                                   # opcional
AUTORIZACAO = 'Semana 30/11–06/12 autorizada em 27/11/2026'     # opcional
POSTS = [ {...}, {...} ]
```

## Campos de cada post

| Campo | Tipo | Observação |
|---|---|---|
| `id` | str | `MARCA-AAAAMMDD-01`, por exemplo `MEDQ-20261201-01` |
| `marca` | `'Aristo'` ou `'MedQ'` | define paleta e logo |
| `data` | `'AAAA-MM-DD'` | data prevista de publicação |
| `banca`, `ano`, `q` | str | `'USP-SP'`, `'2024'`, `'Q082'`, como no relatório e no banco |
| `area`, `tema`, `titulo` | str | metadados da biblioteca (não vão para a arte) |
| `gabarito` | `'A'`…`'E'` | conferido com o banco e com a literatura |
| `linha` | str | linha editorial do relatório (`PMB`, `Ponto Cego de raciocínio`…) |
| `capa` | `{headline, dado}` | `**...**` destaca em cor; ver regras do gancho |
| `enunciado` | str **ou lista de str** | literal; uma lista gera um card por parte |
| `comando` | str | a pergunta final do enunciado (pode ser `''`) |
| `alternativas` | `{'A': ..., 'B': ...}` | literais |
| `imagem` | str (opcional) | caminho da imagem original, relativo ao `conteudo.py` |
| `raio` | `{titulo, linhas, nota}` | `linhas` = lista de `(valor, rótulo, é_o_gabarito_ou_topo: 0/1)` |
| `vies` | lista de `(título, texto)` | 2 itens: por que as alternativas erradas atraem |
| `pulo` | `{pergunta, blocos, gabarito}` | `blocos` = 2 tuplas `(título, texto)` |
| `fecho` | str | frase final própria do post |
| `pergunta` | str | pergunta ao leitor no fechamento |
| `legenda` | str | legenda do Instagram, com hashtags |

## Exemplo mínimo

```python
dict(
    id='MEDQ-20261130-01', marca='MedQ', data='2026-11-30', banca='IPSEMG', ano='2024', q='Q013',
    area='Cirurgia Geral', tema='Insuficiência venosa crônica: CEAP', titulo='CEAP: a úlcera ainda está aberta',
    gabarito='A', linha='Ponto Cego de raciocínio',
    capa=dict(headline='Úlcera venosa aberta nas duas pernas. **44% chamaram de cicatrizada.**',
              dado='Só 29,4% acertaram a CEAP. C5 ou C6?'),
    enunciado='Paciente do sexo feminino, 55 anos, ... **úlcera próximo de maléolo medial, medindo cerca de 2cm, com fundo granulado** ...',
    comando='De acordo com as Classificação CEAP ..., esta paciente deve ser categorizada na avaliação clínica como',
    alternativas={'A': 'C6.', 'B': 'C5.', 'C': 'C4.', 'D': 'C3.'},
    raio=dict(titulo='Distribuição das respostas',
              linhas=[('44%', 'marcaram C5 (alternativa B)', 0), ('29,4%', 'marcaram C6, a correta (alternativa A)', 1)],
              nota='O distrator atraiu **mais** que o gabarito.'),
    vies=[('Por que o C5 atrai', 'C5 e C6 falam de úlcera. O que muda é se ela já fechou (C5) ou se continua aberta (C6).'),
          ('O que o enunciado mostra', 'Duas úlceras com fundo granulado, de 2 cm e 5 cm. Estão abertas.')],
    pulo=dict(pergunta='A escada clínica da CEAP',
              blocos=[('C3 e C4', '...'), ('C5 e C6', '...')],
              gabarito='Gabarito A: úlcera aberta é C6.'),
    fecho='Cicatrizada é C5. Aberta é C6. A questão inteira cabe nessa diferença.',
    pergunta='Você teria marcado C5? Diga nos comentários.',
    legenda='Úlcera venosa aberta nas duas pernas, e 44% dos alunos a classificaram como cicatrizada. ... #MedQ #IPSEMG #CirurgiaVascular #ResidenciaMedica',
)
```
