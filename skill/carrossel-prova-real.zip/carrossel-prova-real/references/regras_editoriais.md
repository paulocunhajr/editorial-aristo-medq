# Regras editoriais: carrossel "prova real"

## Sumário
1. Estrutura dos cards
2. O gancho (capa)
3. As marcas
4. Números: o que pode e o que não pode
5. Tom e frases proibidas
6. Passada de humanização (checklist)
7. Exemplos aprovados

## 1. Estrutura dos cards
| # | Card | Conteúdo |
|---|---|---|
| 1 | Capa (escura) | "PROVA REAL • BANCA ANO", gancho com destaque, linha de apoio (dado + pergunta ao leitor), botão "Veja a questão ›", logo |
| 2+ | Questão oficial | Enunciado literal com as pistas decisivas em **negrito**, comando e alternativas. Se for longo, vira várias partes ("Continua ›") e um card só de alternativas |
| n | Card de dados | 2 ou 3 números grandes do relatório (gabarito × distrator, ou topo × média), uma nota e dois "por que erraram". Balão "Por que erraram? ›" |
| n+1 | O que a banca cobrou (cor da marca) | Pergunta-guia, dois blocos de resolução e caixa com o gabarito |
| n+2 | Fechamento (escuro) | Frase final própria do post, pergunta ao leitor, "Salve para revisar ›" e "Envie para quem vai fazer a/o BANCA ›" |

Nada de numeração de card ("2/6"), chancela de dados nem etiqueta de área/tema nas artes (decisão de 27/11/2026). Nada de placeholder na arte: se falta um dado, o post não sai.

## 2. O gancho (capa)
**Fórmula:** cena clínica concreta, no vocabulário do plantão, + % real de erro ou o distrator, em destaque (`**...**`).

Bons ganchos:
- "Bebê de 1 mês, sem vacina, na casa de um paciente com TB. **43% erraram a conduta.**"
- "Prematuro de 800 g convulsionando. **Metade da prova correu para a glicose.**"
- "Facada no tórax, toracotomia já feita. **89% erraram o que fazer com o abdome.**"
- "Coma com pupilas médio-fixas. **41% apontaram a lesão no lugar errado.**"

Fracos (não use):
- "Só 40,5% dos candidatos medianos acertaram": vago, jargão de quintil.
- "Questão sobre tuberculose na USP": sem cena e sem dado.
- Gancho que entrega a resposta ("Ferritina baixa: anemia ferropriva").

Escolha do número, nesta ordem:
1. % do distrator dominante quando ele supera ou quase iguala o gabarito ("44% chamaram de cicatrizada").
2. % de erro geral = 100 − acerto ("89% erraram").
3. Contraste topo × base, quando é o próprio achado (Ponto Cego de nível: "Até entre os melhores alunos, mais da metade errou").

A linha de apoio completa com o outro dado e uma pergunta direta ao leitor ("Você marcaria C5 ou C6?").

## 3. As marcas
- **Aristo:** estratégia, raciocínio e método de revisão. Azul #1677FF sobre marinho. Fechamento orientado a "o que levar para a prova".
- **MedQ:** resolução, desempenho e aprendizagem com o erro. Roxo #452B9A com ciano #00DFE3 (paleta oficial; também #B07DF4 e #414042). Fechamento orientado a "onde a questão derruba".
- Os dados vêm da plataforma Aristo e podem ser usados nas duas marcas. Não cite o número de alunos.

## 4. Números
- Copie os números do relatório como vieram (vírgula decimal: 56,9%).
- Pode arredondar em capa e legenda (43,1% → 43%), mas nunca para cima de forma que mude o sentido.
- Derivados permitidos: complemento do acerto (100 − x), diferença entre quintis (Q5 − Q3), "metade", "quase 7 em cada 10" (só se a conta fechar: 68,5% → "quase 7 em 10").
- Proibido: estimar a distribuição das alternativas que o relatório não traz, somar as "demais" ou citar dado de engajamento.
- Registre na ficha (`raio.nota` e `justificativa_selecao`) a origem de cada número.

## 5. Tom e frases proibidas
Conversa clínica séria entre colegas. Segunda pessoa com moderação. Sem emoji.

Proibidas: "regra de ouro", "virada de chave", "o segredo dos aprovados", "não é sobre volume", "jornada", "mergulhe", "desvende", "candidatos medianos" e "quintil" na capa e na legenda.

Evite ainda:
- frase de efeito sem conteúdo ("A banca sabe disso");
- repetir a mesma fórmula de fechamento em todos os posts ("A USP cobrou exatamente essa diferença");
- atribuir ao aluno um motivo de erro que o dado não mostra. "Erram por pressa" é especulação; "o comando é negativo" é fato do enunciado.

## 6. Passada de humanização (checklist)
Faça antes de conferir:
- [ ] Cada fechamento tem frase e pergunta próprias. Nenhuma estrutura se repete em três posts seguidos.
- [ ] Nada de tríades decorativas, de "não é X, é Y" em série nem de dois-pontos dramáticos em toda frase.
- [ ] Frases curtas, verbos concretos, termos de plantão ("trata", "interna", "pede tomografia").
- [ ] Explicações dizem o fato clínico, não o rótulo ("C5 é a úlcera já cicatrizada; C6, a aberta").
- [ ] A legenda abre com a cena e o dado (o mesmo gancho da capa), diz o que o carrossel resolve, traz data da prova e 4 hashtags (#Marca #Banca #Área #ResidenciaMedica). Sem "Dados da plataforma…".
- [ ] Nenhuma informação nova sem fonte. Nenhum número tocado na revisão.

## 7. Exemplos aprovados
Ver `exemplo_conteudo_semana_usp_ipsemg.py`: 14 posts (USP-SP 2024 e IPSEMG 2024), revisados e publicados para aprovação em 27/11/2026.
