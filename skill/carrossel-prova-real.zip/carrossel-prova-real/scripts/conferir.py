"""Confere o arquivo de conteúdo antes de renderizar/entregar.

Uso:
    python3 scripts/conferir.py conteudo.py --banco banco.csv --radar radar1.json [radar2.json ...]

1. Texto: enunciado + comando e alternativas de cada post batem com o banco (ignora negrito,
   espaços e acentuação corrigida é apontada para revisão manual); gabarito igual ao do banco.
2. Números: todo "NN%" ou "NN pontos" em capa, card de dados, vieses, fecho e legenda precisa existir
   no relatório daquele item OU ser derivado dele (complemento do acerto: 100 - acerto; gap entre quintis;
   versão arredondada). Números sem origem saem como ERRO.
3. Frases proibidas (ver references/regras_editoriais.md).
Sai com código 1 se houver erro.
"""
import argparse, csv, importlib.util, json, re, sys, unicodedata

csv.field_size_limit(10 ** 9)
PROIBIDAS = ['regra de ouro', 'virada de chave', 'segredo dos aprovados', 'não é sobre volume', 'candidatos medianos',
             'quintil', 'jornada', 'mergulh', 'desvend', 'game changer', 'pulo do gato definitivo']


def n(s):
    s = re.sub(r'\*\*|!\[\]\([^)]*\)', '', s)
    s = unicodedata.normalize('NFKD', s).encode('ascii', 'ignore').decode()
    return re.sub(r'[\s.]+', '', s).lower()


def f(x):
    return round(float(x.replace(',', '.')), 1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('conteudo'); ap.add_argument('--banco'); ap.add_argument('--radar', nargs='*', default=[])
    a = ap.parse_args()
    spec = importlib.util.spec_from_file_location('c', a.conteudo); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    banco = {}
    if a.banco:
        with open(a.banco, encoding='utf-8-sig', newline='') as fh:
            for r in csv.DictReader(fh):
                try: banco[(r['instituicao'], r['ano'], int(r['ordem']))] = r
                except (KeyError, ValueError): pass
    radar = {}
    for p in a.radar:
        d = json.load(open(p))
        prova = d['cabecalho'].get('prova', '').split(' (')[0]; ano = d['cabecalho'].get('ano', '')
        for it in d['tabela'] + d['exemplos']:
            nums = set()
            for v in re.findall(r'[\d,]+(?=%|pp)', json.dumps(it, ensure_ascii=False)):
                nums.add(f(v))
            radar.setdefault((prova, ano, it['q']), set()).update(nums)
    erros = 0
    for p in m.POSTS:
        tag = f"{p['id']} ({p['banca']} {p['ano']} {p['q']})"
        r = banco.get((p['banca'], p['ano'], int(p['q'][1:])))
        if a.banco:
            if not r:
                print('AVISO', tag, 'questão não está no banco');
            else:
                e = p['enunciado'] if isinstance(p['enunciado'], str) else ' '.join(p['enunciado'])
                if n(e + p.get('comando', '')) != n(r['enunciado']):
                    print('REVISAR', tag, 'enunciado difere do banco (pode ser só correção de digitação)')
                if r.get('alternativas'):
                    of = [x[3:] for x in re.split(r'\n(?=[A-E]\) )', r['alternativas'].strip())]
                    for (k, v), o in zip(p['alternativas'].items(), of):
                        if n(v) != n(o): print('REVISAR', tag, f'alternativa {k} difere do banco')
                if r.get('gabarito') and r['gabarito'] != p['gabarito']:
                    print('ERRO', tag, f"gabarito {p['gabarito']} ≠ banco {r['gabarito']}"); erros += 1
        base = radar.get((p['banca'], p['ano'], p['q']), set())
        if radar and not base:
            print('ERRO', tag, 'item não encontrado nos relatórios informados'); erros += 1
        ok = set(base) | {round(100 - x, 1) for x in base} | {20.0, 100.0}
        ok |= {round(abs(x - y), 1) for x in base for y in base}
        ok |= {round(x) for x in ok}
        txt = json.dumps({k: p.get(k) for k in ['capa', 'raio', 'vies', 'fecho', 'legenda']}, ensure_ascii=False)
        for v in re.findall(r'(\d+(?:,\d+)?)\s*(?:%|pontos)', txt):
            x = f(v)
            if radar and x not in ok and round(x) not in ok:
                print('ERRO', tag, f'número {v} sem origem no relatório'); erros += 1
        vitrine = json.dumps({k: p.get(k) for k in ['capa', 'fecho', 'legenda']}, ensure_ascii=False).lower()
        for fr in PROIBIDAS:  # capa, fechamento e legenda são o que o público lê primeiro
            if fr in vitrine:
                print('ERRO', tag, f'frase proibida: "{fr}"'); erros += 1
    print('\nerros:', erros)
    sys.exit(1 if erros else 0)


if __name__ == '__main__':
    main()
