"""Busca uma questão no banco (questoes-discriminacao*.csv) pelo número do item do relatório.

Uso:
    python3 scripts/buscar_questao.py banco.csv USP-SP 2024 Q082 [Q004 ...]

Mostra enunciado, alternativas, gabarito, discriminação, se há imagem e o CCQ do comentário.
O banco "completo" tem as colunas alternativas/gabarito/comentario; o banco "simples" só tem o enunciado.
"""
import csv, re, sys

csv.field_size_limit(10 ** 9)


def main(banco, inst, ano, qs):
    idx = {}
    with open(banco, encoding='utf-8-sig', newline='') as fh:
        for r in csv.DictReader(fh):
            try:
                idx[(r['instituicao'], r['ano'], int(r['ordem']))] = r
            except (KeyError, ValueError):
                pass
    for q in qs:
        r = idx.get((inst, ano, int(q.lstrip('Qq'))))
        print(f"\n===== {inst} {ano} {q}")
        if not r:
            print('NÃO ENCONTRADA no banco'); continue
        print(f"gabarito: {r.get('gabarito', '(banco sem gabarito)')} | discriminação: {r.get('discriminacao')} | imagens: {r.get('qtd_imagens')}")
        print(r['enunciado'].strip())
        if r.get('alternativas'):
            print(r['alternativas'].strip())
        cc = re.search(r'CCQ:\s*([^*\n]+)', r.get('comentario', '') or '')
        if cc:
            print('CCQ:', cc.group(1).strip())


if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4:])
