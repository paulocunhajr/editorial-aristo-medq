"""Extrai o relatório "Radar de Conteúdo Editorial" (PDF do painel Aristo) para JSON.

Uso:
    python3 scripts/extrair_radar.py relatorio.pdf > radar.json

Saída: cabeçalho (prova, nº de alunos, itens válidos/anulados) e duas listas:
  - "tabela": todas as linhas das tabelas de cada linha editorial (PMB, Ponto Cego de nível,
    Ponto Cego de raciocínio, Pulo do Gato, Conteúdos fundamentais), com os números como vieram.
  - "exemplos": os itens detalhados (enunciado, alternativas, gabarito, % de quem marcou o distrator,
    acerto geral e por quintil, CCQ do comentário oficial).
Depende do pdftotext (poppler-utils).
"""
import json, re, subprocess, sys

LINHAS = ['PMB', 'Ponto Cego de nível', 'Ponto Cego de raciocínio', 'Pulo do Gato', 'Conteúdos fundamentais']


def texto(pdf):
    return subprocess.run(['pdftotext', '-layout', pdf, '-'], capture_output=True, text=True, check=True).stdout


def num(s):
    return float(s.replace(',', '.').replace('%', '').replace('pp', '').replace('+', ''))


def main(pdf):
    t = texto(pdf)
    L = t.split('\n')
    cab = {}
    m = re.search(r'([A-Z][\w\- ]+\(\w\w\)) (\d{4}) - oportunidades', t)
    if m:
        cab['prova'], cab['ano'] = m.group(1).strip(), m.group(2)
    m = re.search(r'(\d+) aluno\(s\) resolveram esta prova, com (\d+) no menor quintil\. (\d+) itens válidos; (\d+) anulado', t)
    if m:
        cab.update(alunos=int(m.group(1)), menor_quintil=int(m.group(2)), itens_validos=int(m.group(3)), anulados=int(m.group(4)))
    cab['amostra_pequena'] = 'Amostra pequena' in t

    tabela, exemplos, sec = [], [], None
    i = 0
    while i < len(L):
        l = L[i]
        m = re.match(r'^\s*\d\. (' + '|'.join(LINHAS) + r')', l)
        if m and 'Critério' in '\n'.join(L[i:i + 4]):
            sec = m.group(1)
        m = re.match(r'^\s*(Q\d{3})\s{2,}(.+)$', l)
        if m and sec:
            resto = m.group(2)
            pct = re.findall(r'[\d,]+%', resto)
            pp = re.findall(r'[+-][\d,]+pp', resto)
            dist = re.search(r'([A-E]): ([\d,]+%)', resto)
            tabela.append(dict(linha=sec, q=m.group(1), texto=re.sub(r'\s{2,}', ' | ', resto.strip()),
                               acerto=pct[0] if pct else None, gaps=pp,
                               distrator=(dist.group(1), dist.group(2)) if dist else None))
        m = re.match(r'^\s*(Q\d{3}) - (.+?) > (.+)$', l)
        if m and i + 1 < len(L) and '% acerto geral' in L[i + 1]:
            stats = L[i + 1].strip()
            j = i + 2
            corpo = []
            while j < len(L) and not re.match(r'^\s*Q\d{3} - ', L[j]) and not re.match(r'^\s*\d\. (' + '|'.join(LINHAS) + ')', L[j]):
                corpo.append(L[j]); j += 1
            b = '\n'.join(corpo)
            enun = b.split('Enunciado:', 1)[-1].split('Comentário oficial:', 1)[0]
            alts, marcas = {}, {}
            atual = None
            linhas_enun = []
            for x in enun.split('\n'):
                ma = re.match(r'^\s*([A-E])\) (.*)$', x)
                if ma:
                    atual = ma.group(1); txt = ma.group(2)
                    mk = re.search(r'\s{2,}\((correta|[\d,]+% marcou)\)\s*$', txt)
                    if mk:
                        marcas[atual] = mk.group(1); txt = txt[:mk.start()]
                    alts[atual] = txt.strip()
                elif atual and x.strip():
                    mk = re.search(r'\s{2,}\((correta|[\d,]+% marcou)\)\s*$', x)
                    if mk:
                        marcas[atual] = mk.group(1); x = x[:mk.start()]
                    alts[atual] += ' ' + x.strip()
                elif not atual:
                    linhas_enun.append(x.strip())
            ccq = re.search(r'CCQ:\s*(.+?)\n\s*\n', b, re.S)
            exemplos.append(dict(
                linha=sec, q=m.group(1), area=m.group(2).strip(), tema=m.group(3).strip(), estatistica=stats,
                acerto_geral=re.search(r'% acerto geral: ([\d,]+%)', stats).group(1),
                quintis=dict(re.findall(r'% acerto no (Q\d) \([^)]*\): ([\d,]+%)', stats)),
                distrator_dominante=re.findall(r'alternativa ([A-E]) com ([\d,]+%)', stats),
                enunciado=re.sub(r'\s+', ' ', ' '.join(linhas_enun)).strip(),
                alternativas=alts, marcas=marcas,
                gabarito=next((k for k, v in marcas.items() if v == 'correta'), None),
                tem_imagem=bool(re.search(r'imagem (a seguir|abaixo)|conforme imagem|na imagem', enun, re.I)),
                ccq=re.sub(r'\s+', ' ', ccq.group(1)).strip() if ccq else ''))
            i = j
            continue
        i += 1
    json.dump(dict(cabecalho=cab, tabela=tabela, exemplos=exemplos), sys.stdout, ensure_ascii=False, indent=1)


if __name__ == '__main__':
    main(sys.argv[1])
